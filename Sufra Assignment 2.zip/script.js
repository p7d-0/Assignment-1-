/* External JavaScript */
var large = false;
var slide = 1;
var mealTotal = 5;

function showMessage(id, text, isError) {
  var box = document.getElementById(id);
  box.innerHTML = text;
  if (isError) {
    box.style.color = "#b00020";
  } else {
    box.style.color = "";
  }
}

function checkField(id) {
  var field = document.getElementById(id);
  var value = field.value;
  var message = "";

  switch (id) {
    case "lemail":
    case "semail":
    case "c3":
      if (!value.includes("@") || !value.includes(".")) {
        message = "Enter a valid email such as name@example.com.";
      }
      break;
    case "lpass":
    case "spass":
      if (value.length < 6) {
        message = "Password must be at least 6 characters.";
      }
      break;
    case "spass2":
      if (value == "" || value != document.getElementById("spass").value) {
        message = "Passwords do not match.";
      }
      break;
    case "sphone":
      if (value != "" && value.length != 10) {
        message = "Mobile must look like 05XXXXXXXX.";
      }
      break;
    case "sname":
      if (value.trim().length < 3) {
        message = "Please enter your full name (at least 3 characters).";
      }
      break;
    case "c1":
    case "fname":
      if (value.trim().length < 2) {
        message = "Please enter your name.";
      }
      break;
    case "c2":
      if (value.trim().length < 10) {
        message = "Details must be at least 10 characters.";
      }
      break;
    case "msg":
      if (value.trim().length < 10) {
        message = "Comments must be at least 10 characters.";
      }
      break;
    case "mdish":
    case "marea":
      if (value.trim().length < 3) {
        message = "Dish and neighbourhood must be at least 3 characters.";
      }
      break;
  }

  if (message == "") {
    field.style.borderColor = "";
    field.style.background = "";
  } else {
    field.style.borderColor = "#b00020";
    field.style.background = "#fff4f5";
  }
  return message;
}

function blurField(id, messageId) {
  showMessage(messageId, checkField(id), true);
}

function checkLogin() {
  var emailMessage = checkField("lemail");
  var passwordMessage = checkField("lpass");

  var message = emailMessage;
  if (message == "") message = passwordMessage;

  showMessage("lerr", message, true);
  return message == "";
}

function showStrength() {
  var length = document.getElementById("spass").value.length;
  var meter = document.getElementById("strength");

  if (length == 0) {
    meter.innerHTML = "";
  } else if (length < 6) {
    meter.innerHTML = "Password strength: Weak";
    meter.style.color = "#b00020";
  } else if (length < 8) {
    meter.innerHTML = "Password strength: Medium";
    meter.style.color = "#b8860b";
  } else {
    meter.innerHTML = "Password strength: Strong";
    meter.style.color = "#2F7A4A";
  }
}

function showHint(role) {
  var hint = document.getElementById("roleHint");

  switch (role) {
    case "donor":
      hint.innerHTML = "As a donor you can post surplus meals with a pickup time.";
      break;
    case "receiver":
      hint.innerHTML = "As a receiver you can claim nearby meals for free.";
      break;
    default:
      hint.innerHTML = "";
  }
}

function checkSignup() {
  var nameMessage = checkField("sname");
  var emailMessage = checkField("semail");
  var phoneMessage = checkField("sphone");
  var passwordMessage = checkField("spass");
  var matchMessage = checkField("spass2");

  var message = nameMessage;
  if (message == "") message = emailMessage;
  if (message == "") message = phoneMessage;
  if (message == "") message = passwordMessage;
  if (message == "") message = matchMessage;

  showMessage("serr", message, true);
  return message == "";
}

function sendContact() {
  var nameMessage = checkField("c1");
  var emailMessage = checkField("c3");
  var detailsMessage = checkField("c2");

  var message = nameMessage;
  if (message == "") message = emailMessage;
  if (message == "") message = detailsMessage;

  if (message != "") {
    showMessage("cok", message, true);
  } else {
    var name = document.getElementById("c1").value.trim();
    var email = document.getElementById("c3").value.trim();
    showMessage("cok", "Thank you, " + name + "! We will reply to " + email + ".", false);
    document.getElementById("contactForm").reset();
  }
  return false;
}

function countCharacters() {
  var length = document.getElementById("msg").value.length;
  var counter = document.getElementById("count");

  counter.innerHTML = length + " / 200";
  if (length >= 180) {
    counter.style.color = "#b00020";
  } else {
    counter.style.color = "";
  }
}

function sendFeedback() {
  var nameMessage = checkField("fname");
  var commentMessage = checkField("msg");

  var message = nameMessage;
  if (message == "") message = commentMessage;

  if (message != "") {
    showMessage("fbok", message, true);
  } else {
    var name = document.getElementById("fname").value.trim();
    var rating = parseInt(document.getElementById("rate").value);
    showMessage("fbok", "Thank you, " + name + "! You rated us " + rating + "/5. Feedback received.", false);
    document.getElementById("fbForm").reset();
    countCharacters();
  }
  return false;
}

function filterMeals() {
  var text = document.getElementById("q").value.toLowerCase();
  var shown = 0;

  for (var i = 1; i <= mealTotal; i++) {
    var name = document.getElementById("name" + i).innerHTML.toLowerCase();
    if (name.includes(text)) {
      document.getElementById("meal" + i).style.display = "";
      shown++;
    } else {
      document.getElementById("meal" + i).style.display = "none";
    }
  }

  document.getElementById("mealCount").innerHTML = shown + " of " + mealTotal + " meals shown";
}

function claimMeal(number, button) {
  document.getElementById("meal" + number).style.opacity = "0.55";
  document.getElementById("name" + number).style.textDecoration = "line-through";
  button.innerHTML = "Claimed";
}

function postMeal() {
  var dishMessage = checkField("mdish");
  var areaMessage = checkField("marea");

  var message = dishMessage;
  if (message == "") message = areaMessage;

  if (message != "") {
    showMessage("mok", message, true);
  } else {
    var dish = document.getElementById("mdish").value.trim();
    var area = document.getElementById("marea").value.trim();
    var list = document.getElementById("results");

    mealTotal++;
    list.innerHTML = '<li id="meal' + mealTotal + '"><span id="name' + mealTotal + '">' + dish + " – " + area + '</span><button type="button" onclick="claimMeal(' + mealTotal + ', this)">Claim</button></li>' + list.innerHTML;

    document.getElementById("mealForm").reset();
    document.getElementById("q").value = "";
    filterMeals();
    showMessage("mok", "Meal posted – thank you for sharing!", false);
  }
  return false;
}

function showSlide(number) {
  var caption = "";

  if (number > 3) number = 1;
  if (number < 1) number = 3;
  slide = number;

  switch (number) {
    case 1:
      caption = "Fresh bread shared in Al Rawdah";
      break;
    case 2:
      caption = "Dates and fruit shared in Al Safa";
      break;
    case 3:
      caption = "Rice and lentils shared in Al Balad";
      break;
  }

  document.getElementById("slideBox").innerHTML = '<img id="slideImg" src="images/slide' + number + '.svg" alt="' + caption + '" width="600" height="300"><figcaption id="slideCap">' + caption + "</figcaption>";
}

function changeTextSize() {
  var button = document.getElementById("themeBtn");

  if (large) {
    document.body.style.fontSize = "";
    button.innerHTML = "Larger text";
    large = false;
  } else {
    document.body.style.fontSize = "larger";
    button.innerHTML = "Normal text";
    large = true;
  }
}

var greetingBox = document.getElementById("greeting");
if (greetingBox) {
  var hour = new Date().getHours();
  greetingBox.innerHTML = (hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening") + " – someone nearby has food to share.";
}

if (document.getElementById("roleHint")) {
  showHint("donor");
}

if (document.getElementById("mealCount")) {
  filterMeals();
}
