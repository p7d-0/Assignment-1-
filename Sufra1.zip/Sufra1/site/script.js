/* External JavaScript */
document.addEventListener("DOMContentLoaded", function () {
  var g = document.getElementById("greeting");
  if (g) { var h = new Date().getHours(); g.textContent = (h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening") + " – someone nearby has food to share."; }

  var login = document.getElementById("loginForm");
  if (login) login.addEventListener("submit", function (e) {
    var ok = login.email.value.includes("@") && login.password.value.length >= 6;
    if (!ok) { e.preventDefault(); document.getElementById("lerr").textContent = "Enter a valid email and a password of at least 6 characters."; }
  });

  var su = document.getElementById("signupForm");
  if (su) su.addEventListener("submit", function (e) {
    var msg = "";
    if (!su.name.value.trim()) msg = "Please enter your full name.";
    else if (!su.email.value.includes("@")) msg = "Please enter a valid email.";
    else if (su.password.value.length < 6) msg = "Password must be at least 6 characters.";
    else if (su.password.value !== document.getElementById("spass2").value) msg = "Passwords do not match.";
    if (msg) { e.preventDefault(); document.getElementById("serr").textContent = msg; }
  });

  var fb = document.getElementById("fbForm");
  if (fb) fb.addEventListener("submit", function (e) { e.preventDefault(); document.getElementById("fbok").textContent = "Thank you, " + document.getElementById("fname").value + "! Feedback received."; fb.reset(); });

  var q = document.getElementById("q");
  if (q) { document.getElementById("searchForm").addEventListener("submit", function (e) { e.preventDefault(); });
    q.addEventListener("input", function () { var t = q.value.toLowerCase(); document.querySelectorAll("#results li").forEach(function (li) { li.style.display = li.textContent.toLowerCase().includes(t) ? "" : "none"; }); }); }
});
